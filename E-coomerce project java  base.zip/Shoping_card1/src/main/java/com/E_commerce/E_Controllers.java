package com.E_commerce;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class E_Controllers{
	
	@GetMapping("/")
	public String index() {
		
		return "index";
		
	}
	
	@GetMapping("/login")
	public String login() {
		
		return "login";
		
	}
	@GetMapping("/Register")
	public String Register() {
		
		return "register";
		
	}
	
	@GetMapping("/products")
	public String products() {
	   
	    return "product";
	}
	@GetMapping("/product")
	public String product() {
	   
	    return "view_product";
	}
	
}


