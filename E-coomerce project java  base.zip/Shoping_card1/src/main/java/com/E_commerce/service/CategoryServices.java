package com.E_commerce.service;

import java.util.List;

import com.E_commerce.model.Category;

public interface CategoryServices {

	public Category saveCategory(Category category);
	
	public Boolean existCategory(String name);
	
	public List<Category> getAllCategory();
}
