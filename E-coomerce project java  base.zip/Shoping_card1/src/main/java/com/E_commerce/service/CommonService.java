package com.E_commerce.service;

public interface CommonService {

	public void removeSessionMessage();
}
