package com.E_commerce;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.E_commerce.model.Category;
import com.E_commerce.service.CategoryServices;


import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class Admin_controller {

	@Autowired
	private CategoryServices categoryServices;
	
	@GetMapping("/index")
	public String index() {
		
		return "admin/index";
	}
	
	@GetMapping("/Add_products")
	public String Add_products() {
		
		return "admin/Add_products";
	}
	@GetMapping("/category")
	public String category() {
		
		return "admin/category";
	}
	
	@PostMapping("/saveCategory")
	public String saveCategory(@ModelAttribute Category category,@RequestParam("file") MultipartFile file, HttpSession httpSession) throws IOException {
		
		String imageName = file!= null ? file.getOriginalFilename(): "default.jpg";
		category.setImagename(imageName);
		Boolean existCategory = categoryServices.existCategory(category.getName());
		if (existCategory) {
			
			httpSession.setAttribute("errorMsg", "category name already exixts");
			
		}
		else {
			
			Category savecategory = categoryServices.saveCategory(category);
			if(ObjectUtils.isEmpty(savecategory))
				
			{
				
			httpSession.setAttribute("errorMsg","not saved ! internal server error");
			}else {
				
				File savefile =new ClassPathResource("static/img").getFile();
				Path path =	Paths.get(savefile.getAbsolutePath()+File.separator+"category"+File.separator+file.getOriginalFilename());
				
				System.out.println(path);
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				
				
				httpSession.setAttribute("succMsg","Saved successfully");
			}
			
		}
		
		return "redirect:/admin/category";
	}
}
