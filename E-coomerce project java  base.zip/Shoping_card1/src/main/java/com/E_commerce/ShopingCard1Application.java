package com.E_commerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopingCard1Application {

	public static void main(String[] args) {
		SpringApplication.run(ShopingCard1Application.class, args);
	}

}
