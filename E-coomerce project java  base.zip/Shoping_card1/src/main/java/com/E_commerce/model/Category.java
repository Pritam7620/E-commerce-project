package com.E_commerce.model;





import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	 private String name;
	 private String imagename;
	 private Boolean isActive;
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImagename() {
		return imagename;
	}
	public void setImagename(String imagename) {
		this.imagename = imagename;
	}
	public Boolean isActive() {
		return isActive;
	}
	public void setActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Category(int id, String name, String imagename, Boolean isActive) {
		super();
		this.id = id;
		this.name = name;
		this.imagename = imagename;
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + ", imagename=" + imagename + ", isActive=" + isActive + "]";
	}
	
	 
}
