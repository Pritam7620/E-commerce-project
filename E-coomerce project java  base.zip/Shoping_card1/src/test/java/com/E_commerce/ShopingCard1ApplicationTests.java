package com.E_commerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopingCard1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
